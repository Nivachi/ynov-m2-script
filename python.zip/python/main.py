# main.py
import click
from utils.helpers import capitalize_all, add_numbers, log_execution

@click.group()
def cli():
    pass

@cli.command()
@click.argument('text')
def format(text):
    """Met en majuscules toutes les lettres."""
    print(capitalize_all(text))

@cli.command()
@click.argument('numbers', nargs=-1, type=int)
def somme(numbers):
    """Additionne une liste de nombres."""
    print(f"Somme : {add_numbers(numbers)}")

@cli.command()
def demo_decorateur():
    """Démontre le fonctionnement du décorateur."""
    @log_execution
    def exemple():
        print("Fonction en cours...")

    exemple()

if __name__ == '__main__':
    cli()
