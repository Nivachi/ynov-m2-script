# utils/helpers.py
def capitalize_all(text):
    return text.upper()

def add_numbers(numbers):
    return sum(numbers)

def log_execution(func):
    def wrapper(*args, **kwargs):
        print(f"▶ Exécution de {func.__name__}")
        result = func(*args, **kwargs)
        print(f"✓ Fin d'exécution de {func.__name__}")
        return result
    return wrapper
