# Projet Python CLI

## Objectif
Ce projet est un exemple de script en ligne de commande Python avec des fonctions utilitaires.

## Installation

### 1. Cloner le repo

```bash
git clone <repo-url>
cd mon_projet
